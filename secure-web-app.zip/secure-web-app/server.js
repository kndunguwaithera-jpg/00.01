require("dotenv").config();
const path = require("path");
const express = require("express");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");

const { wafMiddleware } = require("./middleware/waf");
const { generalLimiter, speedLimiter, authLimiter } = require("./middleware/rateLimiter");
const { ipWhitelist } = require("./middleware/ipWhitelist");
const { requireAuth, requireRole } = require("./middleware/auth");
const authRoutes = require("./routes/auth");

const app = express();

// --- Zero trust starting point: never implicitly trust the network ---
// Only trust X-Forwarded-For if we're actually behind a reverse proxy we
// control (nginx/Cloudflare/ALB). Otherwise req.ip can be spoofed by clients.
if (process.env.TRUST_PROXY === "true") {
  app.set("trust proxy", 1);
}

// --- Security headers (CSP, HSTS, X-Frame-Options, etc.) ---
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'"],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"],
        upgradeInsecureRequests: [],
      },
    },
    hsts: { maxAge: 63072000, includeSubDomains: true, preload: true },
    referrerPolicy: { policy: "no-referrer" },
  })
);

app.disable("x-powered-by");

app.use(express.json({ limit: "50kb" })); // small limit = harder to DoS with huge bodies
app.use(express.urlencoded({ extended: false, limit: "50kb" }));
app.use(cookieParser());

// --- WAF-lite: block obvious malicious payloads before they hit routes ---
app.use(wafMiddleware());

// --- Rate limiting / progressive throttling across the whole app ---
app.use(generalLimiter);
app.use(speedLimiter);

// --- Static frontend ---
app.use(express.static(path.join(__dirname, "public"), { maxAge: "1h" }));

// --- Auth routes get their own stricter limiter on top of the global one ---
app.use("/api/auth", authLimiter, authRoutes);

// --- Zero trust example: every request to /api/me is re-verified, no
// session-based implicit trust ---
app.get("/api/me", requireAuth, (req, res) => {
  res.json({ user: req.user });
});

// --- Admin routes: layered defense = IP allowlist AND valid admin JWT ---
app.use(
  "/admin",
  ipWhitelist(process.env.ADMIN_IP_ALLOWLIST),
  requireAuth,
  requireRole("admin")
);
app.get("/admin/dashboard", (req, res) => {
  res.json({ message: `Welcome, ${req.user.sub}. This is the admin dashboard.` });
});

// --- Health check (safe to expose, no sensitive info) ---
app.get("/healthz", (req, res) => res.json({ status: "ok" }));

// --- 404 handler ---
app.use((req, res) => {
  res.status(404).json({ error: "Not found." });
});

// --- Centralized error handler: never leak stack traces to clients ---
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(`[ERROR] ${req.method} ${req.path}:`, err.message);
  res.status(err.status || 500).json({ error: "Internal server error." });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Secure server listening on port ${PORT} (env: ${process.env.NODE_ENV || "development"})`);
});

module.exports = app;
