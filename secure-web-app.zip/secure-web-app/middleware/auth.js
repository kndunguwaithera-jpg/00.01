const jwt = require("jsonwebtoken");

const MAX_ATTEMPTS = Number(process.env.LOGIN_MAX_ATTEMPTS || 5);
const LOCKOUT_MS = Number(process.env.LOGIN_LOCKOUT_MINUTES || 15) * 60 * 1000;

/**
 * In-memory brute-force tracker keyed by `ip:username`.
 * NOTE: for a multi-instance deployment, replace this Map with Redis (or
 * similar shared store) so lockouts are consistent across app servers.
 */
const attempts = new Map();

function keyFor(ip, username) {
  return `${ip}:${(username || "").toLowerCase()}`;
}

function isLockedOut(ip, username) {
  const record = attempts.get(keyFor(ip, username));
  if (!record) return false;
  if (record.count < MAX_ATTEMPTS) return false;
  const elapsed = Date.now() - record.lastAttempt;
  if (elapsed > LOCKOUT_MS) {
    attempts.delete(keyFor(ip, username));
    return false;
  }
  return true;
}

function recordFailedAttempt(ip, username) {
  const k = keyFor(ip, username);
  const record = attempts.get(k) || { count: 0, lastAttempt: 0 };
  record.count += 1;
  record.lastAttempt = Date.now();
  attempts.set(k, record);
  return record.count;
}

function clearAttempts(ip, username) {
  attempts.delete(keyFor(ip, username));
}

/** Express middleware: blocks login attempts while account/IP is locked out. */
function loginProtector(req, res, next) {
  const { username } = req.body || {};
  if (isLockedOut(req.ip, username)) {
    return res.status(429).json({
      error: `Too many failed login attempts. Try again in a few minutes.`,
    });
  }
  next();
}

function signAccessToken(payload) {
  return jwt.sign(payload, process.env.JWT_ACCESS_SECRET, {
    expiresIn: process.env.JWT_ACCESS_TTL || "15m",
  });
}

function signRefreshToken(payload) {
  return jwt.sign(payload, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_TTL || "7d",
  });
}

/**
 * Zero-trust request verification: every protected request must present a
 * valid, unexpired access token. No implicit trust based on network origin,
 * previous requests, or session cookies alone — the token is re-verified
 * on every single call.
 */
function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : req.cookies?.access_token;

  if (!token) {
    return res.status(401).json({ error: "Authentication required." });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_ACCESS_SECRET);
    req.user = decoded;
    next();
  } catch {
    return res.status(401).json({ error: "Invalid or expired token." });
  }
}

/** Role-based authorization, layered on top of requireAuth. */
function requireRole(role) {
  return (req, res, next) => {
    if (!req.user || req.user.role !== role) {
      return res.status(403).json({ error: "Insufficient privileges." });
    }
    next();
  };
}

module.exports = {
  loginProtector,
  recordFailedAttempt,
  clearAttempts,
  isLockedOut,
  signAccessToken,
  signRefreshToken,
  requireAuth,
  requireRole,
};
