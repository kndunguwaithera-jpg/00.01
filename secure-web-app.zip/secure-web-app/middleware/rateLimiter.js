const rateLimit = require("express-rate-limit");
const slowDown = require("express-slow-down");

const windowMinutes = Number(process.env.RATE_LIMIT_WINDOW_MINUTES || 15);
const maxRequests = Number(process.env.RATE_LIMIT_MAX_REQUESTS || 100);

// Hard cutoff: once a client exceeds the limit in the window, they're blocked
// with a 429 until the window resets.
const generalLimiter = rateLimit({
  windowMs: windowMinutes * 60 * 1000,
  max: maxRequests,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many requests. Please slow down and try again later." },
});

// Progressive throttle: starts adding delay before the hard limiter kicks in,
// so legitimate bursty users feel friction rather than a wall.
const speedLimiter = slowDown({
  windowMs: windowMinutes * 60 * 1000,
  delayAfter: Math.max(1, Math.floor(maxRequests / 2)),
  delayMs: (hits) => hits * 200,
  maxDelayMs: 5000,
});

// Tighter limiter specifically for authentication endpoints (login/register/
// password reset) since these are the highest-value brute-force targets.
const authLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many authentication attempts. Try again later." },
});

module.exports = { generalLimiter, speedLimiter, authLimiter };
