const ipaddr = require("ipaddr.js");

/**
 * Parses a comma-separated list of IPs and/or CIDR ranges from env config,
 * e.g. "127.0.0.1,10.0.0.0/8,2001:db8::/32".
 */
function parseAllowlist(raw) {
  return (raw || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

function isAllowed(ip, allowlist) {
  if (allowlist.length === 0) return false; // fail closed: no list = deny all

  let addr;
  try {
    addr = ipaddr.parse(ip.replace("::ffff:", ""));
  } catch {
    return false;
  }

  for (const entry of allowlist) {
    try {
      if (entry.includes("/")) {
        const [rangeAddr, prefix] = entry.split("/");
        const range = ipaddr.parse(rangeAddr);
        if (addr.kind() === range.kind() && addr.match(range, Number(prefix))) {
          return true;
        }
      } else {
        const single = ipaddr.parse(entry.replace("::ffff:", ""));
        if (addr.kind() === single.kind() && addr.toString() === single.toString()) {
          return true;
        }
      }
    } catch {
      continue; // skip malformed entries rather than crash
    }
  }
  return false;
}

/**
 * Zero-trust-friendly IP allowlist middleware. Fails CLOSED: if no allowlist
 * is configured, every request is denied rather than silently permitted.
 * Intended for sensitive routes (/admin, internal APIs), not the whole site.
 */
function ipWhitelist(rawAllowlist, options = {}) {
  const allowlist = parseAllowlist(rawAllowlist);
  const log = options.logger || console;

  return function ipWhitelistMiddleware(req, res, next) {
    const clientIp = req.ip;
    if (isAllowed(clientIp, allowlist)) {
      return next();
    }
    log.warn(`[IP-ALLOWLIST] Denied ip=${clientIp} path=${req.path}`);
    return res.status(403).json({ error: "Forbidden: your network is not authorized." });
  };
}

module.exports = { ipWhitelist, parseAllowlist, isAllowed };
