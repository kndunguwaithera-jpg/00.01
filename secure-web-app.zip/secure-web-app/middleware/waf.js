/**
 * waf.js — Lightweight, self-hosted Web Application Firewall layer.
 *
 * IMPORTANT: This is a defense-in-depth *supplement*, not a replacement for a
 * real edge WAF (Cloudflare, AWS WAF/Shield, Azure Front Door, ModSecurity/OWASP
 * CRS on nginx). Put one of those in front of this app in production. This
 * middleware catches obvious malicious payloads before they reach your routes
 * and logs/blocks them.
 */

const SUSPICIOUS_PATTERNS = [
  // SQL injection
  /(\%27)|(\')|(--)|(\%23)|(#)/i,
  /((\%3D)|(=))[^\n]*((\%27)|(\')|(--)|(\%3B)|(;))/i,
  /\b(select|union|insert|update|delete|drop|alter|exec|execute)\b.{0,40}\b(from|into|table|database|where)\b/i,
  // XSS
  /<\s*script\b/i,
  /javascript\s*:/i,
  /on(error|load|click|mouseover|focus)\s*=/i,
  /<\s*iframe\b/i,
  // Path traversal
  /(\.\.\/){2,}/,
  /(\.\.\\){2,}/,
  // Command injection
  /(;|\||&&)\s*(cat|ls|whoami|wget|curl|nc|bash|sh|powershell)\b/i,
  // Common scanner / null byte / template injection noise
  /%00/,
  /\{\{.*\}\}/,
];

const MAX_BODY_FIELD_LENGTH = 10_000;

function scanValue(value) {
  if (typeof value === "string") {
    if (value.length > MAX_BODY_FIELD_LENGTH) return "oversized_field";
    for (const pattern of SUSPICIOUS_PATTERNS) {
      if (pattern.test(value)) return pattern.source;
    }
  } else if (Array.isArray(value)) {
    for (const item of value) {
      const hit = scanValue(item);
      if (hit) return hit;
    }
  } else if (value && typeof value === "object") {
    for (const key of Object.keys(value)) {
      const hit = scanValue(value[key]) || scanValue(key);
      if (hit) return hit;
    }
  }
  return null;
}

function wafMiddleware(options = {}) {
  const log = options.logger || console;

  return function waf(req, res, next) {
    const targets = [req.query, req.body, req.params, req.headers["user-agent"]];

    for (const target of targets) {
      const matched = scanValue(target);
      if (matched) {
        log.warn(
          `[WAF] Blocked request ip=${req.ip} path=${req.path} method=${req.method} rule=${matched}`
        );
        return res.status(400).json({ error: "Request blocked by security policy." });
      }
    }

    next();
  };
}

module.exports = { wafMiddleware, SUSPICIOUS_PATTERNS };
