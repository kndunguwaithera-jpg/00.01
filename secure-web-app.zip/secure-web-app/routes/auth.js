const express = require("express");
const bcrypt = require("bcryptjs");
const { body, validationResult } = require("express-validator");
const {
  loginProtector,
  recordFailedAttempt,
  clearAttempts,
  signAccessToken,
  signRefreshToken,
} = require("../middleware/auth");

const router = express.Router();

/**
 * DEMO user store. Replace with a real database (Postgres, etc). Passwords
 * are hashed with bcrypt — never store or log plaintext passwords.
 */
const users = new Map();

const cookieOptions = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "strict",
};

router.post(
  "/register",
  [
    body("username").trim().isLength({ min: 3, max: 32 }).isAlphanumeric(),
    body("password")
      .isLength({ min: 12 })
      .withMessage("Password must be at least 12 characters.")
      .matches(/[A-Z]/)
      .withMessage("Password must contain an uppercase letter.")
      .matches(/[a-z]/)
      .withMessage("Password must contain a lowercase letter.")
      .matches(/[0-9]/)
      .withMessage("Password must contain a number."),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array().map((e) => e.msg) });
    }

    const { username, password } = req.body;
    if (users.has(username.toLowerCase())) {
      return res.status(409).json({ error: "Username already taken." });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    users.set(username.toLowerCase(), { username, passwordHash, role: "user" });

    return res.status(201).json({ message: "Account created. You can now log in." });
  }
);

router.post(
  "/login",
  loginProtector,
  [body("username").trim().notEmpty(), body("password").notEmpty()],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: "Invalid credentials." });
    }

    const { username, password } = req.body;
    const user = users.get((username || "").toLowerCase());

    // Always run bcrypt.compare even on a missing user (against a dummy hash)
    // to avoid leaking account existence via response-time differences.
    const hashToCheck = user ? user.passwordHash : "$2a$12$invalidsaltinvalidsaltinvalidsO";
    const valid = await bcrypt.compare(password, hashToCheck);

    if (!user || !valid) {
      recordFailedAttempt(req.ip, username);
      return res.status(401).json({ error: "Invalid username or password." });
    }

    clearAttempts(req.ip, username);

    const payload = { sub: user.username, role: user.role };
    const accessToken = signAccessToken(payload);
    const refreshToken = signRefreshToken(payload);

    res
      .cookie("access_token", accessToken, { ...cookieOptions, maxAge: 15 * 60 * 1000 })
      .cookie("refresh_token", refreshToken, { ...cookieOptions, maxAge: 7 * 24 * 60 * 60 * 1000 })
      .json({ message: "Logged in.", accessToken });
  }
);

router.post("/logout", (req, res) => {
  res.clearCookie("access_token", cookieOptions);
  res.clearCookie("refresh_token", cookieOptions);
  res.json({ message: "Logged out." });
});

module.exports = router;
