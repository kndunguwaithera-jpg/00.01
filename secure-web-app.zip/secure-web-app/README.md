# Secure Web App

A hardened Node.js/Express web application, built on top of the original
"Legendary Lamp" frontend, with defense-in-depth security controls baked in.

## Security features

| Feature | Where | Notes |
|---|---|---|
| **WAF (lite)** | `middleware/waf.js` | Regex-based filter for SQLi, XSS, path traversal, command injection patterns. **Not a replacement** for an edge WAF — pair with Cloudflare / AWS WAF / ModSecurity in production. |
| **Rate limiting** | `middleware/rateLimiter.js` | Global limiter (`express-rate-limit`) + progressive slow-down + a stricter limiter on `/api/auth/*`. |
| **Login brute-force protection** | `middleware/auth.js`, `routes/auth.js` | Locks out an IP+username pair after N failed attempts for a cooldown window. Passwords hashed with bcrypt (cost 12). Login timing is constant regardless of whether the account exists. |
| **IP allowlisting** | `middleware/ipWhitelist.js` | Fails **closed** — if no allowlist is configured, access is denied, not granted. Applied to `/admin`. Supports single IPs and CIDR ranges, IPv4 and IPv6. |
| **Zero trust architecture** | `middleware/auth.js` (`requireAuth`, `requireRole`) | Every request to a protected route re-verifies a short-lived JWT — no implicit trust from network location, prior requests, or long-lived sessions. Admin routes require IP allowlist **and** a valid admin token (layered checks, least privilege). |
| **Secure headers / hardening** | `server.js` (Helmet) | CSP, HSTS, `X-Frame-Options: DENY` (via `frameAncestors: 'none'`), no `X-Powered-By`, referrer policy, small body-size limits to blunt payload-based DoS. |
| **Regular security patching** | `.github/dependabot.yml`, `.github/workflows/security.yml` | Dependabot opens weekly PRs for vulnerable/outdated npm and GitHub Actions dependencies. CI runs `npm audit` on every push/PR and weekly on a cron, so newly disclosed CVEs get caught even without a code change. |

## Project layout

```
secure-web-app/
├── server.js              # wires all middleware together
├── middleware/
│   ├── waf.js              # pattern-based request filtering
│   ├── rateLimiter.js      # rate limiting + slow-down
│   ├── ipWhitelist.js      # CIDR-aware allowlist, fail-closed
│   └── auth.js             # login lockout + JWT issue/verify (zero trust)
├── routes/
│   └── auth.js             # /api/auth/register, /login, /logout
├── public/                 # static frontend (original lamp demo)
├── .github/
│   ├── dependabot.yml       # weekly dependency updates
│   └── workflows/security.yml  # CI: npm audit on push/PR/weekly cron
└── .env.example             # copy to .env and fill in secrets
```

## Running locally

```bash
npm install
cp .env.example .env
# generate real secrets:
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
# paste the output into JWT_ACCESS_SECRET and JWT_REFRESH_SECRET in .env

npm start
```

Visit `http://localhost:3000`.

## Try the security controls

```bash
# WAF blocks an obvious SQLi probe
curl "http://localhost:3000/api/me?x=1' OR '1'='1"

# Register + login
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"alice","password":"CorrectHorse1Battery"}'

curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"alice","password":"CorrectHorse1Battery"}'

# Hammer the login endpoint to see lockout kick in after LOGIN_MAX_ATTEMPTS
```

## Deployment checklist (production)

- [ ] Put a real edge WAF / CDN in front (Cloudflare, AWS WAF+CloudFront, etc.) — this app's WAF middleware is a second layer, not the first.
- [ ] Terminate TLS (HTTPS) at your load balancer or reverse proxy; set `TRUST_PROXY=true` only if that proxy is trusted and strips/sets `X-Forwarded-For` correctly.
- [ ] Move the in-memory login-attempt tracker and user store to Redis/Postgres — the current versions are single-instance, in-memory demo implementations.
- [ ] Rotate `JWT_ACCESS_SECRET` / `JWT_REFRESH_SECRET` via a secrets manager (not `.env` in prod).
- [ ] Turn on Dependabot alerts in the repo's GitHub Settings so the config in `.github/dependabot.yml` actually files PRs.
- [ ] Set a real `ADMIN_IP_ALLOWLIST` (VPN/office egress IPs or a bastion), not `127.0.0.1`.
- [ ] Add centralized logging/alerting for the `[WAF]`, `[IP-ALLOWLIST]`, and failed-login log lines so blocked attacks are actually noticed.
- [ ] Run `npm audit` / Dependabot review on a schedule — don't let CI-green become "nobody looks."

## Zero trust notes

This app follows "never trust, always verify":
- No route is trusted by default — `requireAuth` re-checks the token on every request, not just at login.
- Admin access requires **two independent controls** to both pass (network origin AND identity), so compromising one doesn't grant access.
- Access tokens are short-lived (15 min default); a stolen token has a small blast radius. Refresh tokens are longer-lived but kept in `httpOnly`, `sameSite=strict` cookies to resist XSS/CSRF theft.
